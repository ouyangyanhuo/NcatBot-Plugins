import logging
import httpx
import time
import traceback
from ncatbot.plugin import BasePlugin, CompatibleEnrollment
from ncatbot.core.message import GroupMessage

bot = CompatibleEnrollment


class DoroPic(BasePlugin):
    name = "DoroPic"
    version = "0.0.1"
    last_called_time = 0  # 上次调用时间
    cooldown_period = 5  # 冷却时间（秒）

    async def on_load(self):
        self.logger = logging.getLogger(f"ncatbot.plugin.{self.name}")

    def is_on_cooldown(self) -> tuple[bool, float]:
        """检查是否在冷却时间内

        Returns:
            tuple[bool, float]: (是否在冷却中, 剩余冷却时间)
        """
        current_time = time.time()
        elapsed_time = current_time - self.last_called_time
        remaining_time = max(0, self.cooldown_period - elapsed_time)
        return (elapsed_time < self.cooldown_period, remaining_time)

    @bot.group_event()
    async def on_group_message(self, msg: GroupMessage):
        if msg.raw_message.lower() == "doro":
            on_cooldown, remaining_time = self.is_on_cooldown()
            if on_cooldown:
                await msg.reply(
                    text=f"请稍等，距离下一次获取随机Doro表情包还有 {remaining_time:.0f} 秒。"
                )
                return
            try:
                async with httpx.AsyncClient() as client:
                    response = await client.get(
                        "https://www.doro.asia/api/random-sticker"
                    )
                    # self.logger.info(response.json())
                    response.raise_for_status()  # 检查 HTTP 状态码
                    data = response.json()  # 解析 JSON
                    if data.get("success", False):  # 检查 API 返回的 success 字段
                        sticker_url = data["sticker"]["url"]
                        if sticker_url:
                            await msg.api.post_group_file(
                                msg.group_id, image=sticker_url
                            )
                        else:
                            await msg.api.post_group_file(
                                msg.group_id, text="未获取到表情包，请稍后再试"
                            )
                    else:
                        await msg.api.post_group_file(msg.group_id, text="API 返回失败")
            except httpx.HTTPStatusError as e:
                error_detail = traceback.format_exc()
                self.logger.error(f"HTTP状态错误: {e}\n{error_detail}")
                await msg.api.post_group_msg(
                    msg.group_id, text=f"API 请求失败，错误码：{e.response.status_code}"
                )
            except httpx.RequestError as e:
                error_detail = traceback.format_exc()
                self.logger.error(f"请求错误: {e}\n{error_detail}")
                await msg.api.post_group_msg(
                    msg.group_id, text=f"请求失败，请检查网络或 API 是否可用"
                )
            except Exception as e:
                error_detail = traceback.format_exc()
                self.logger.error(f"未知错误: {e}\n{error_detail}")
                await msg.api.post_group_msg(msg.group_id, text=f"发生未知错误")
            finally:
                self.last_called_time = time.time()  # 确保更新时间戳

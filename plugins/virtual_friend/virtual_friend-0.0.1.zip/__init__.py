# __init__.py
from .main import virtual_friend

__all__ = ["virtual_friend"]
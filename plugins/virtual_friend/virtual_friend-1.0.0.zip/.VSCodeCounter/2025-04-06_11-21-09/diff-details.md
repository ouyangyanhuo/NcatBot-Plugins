# Diff Details

Date : 2025-04-06 11:21:09

Directory d:\\Myyyyyyyyy\\QQ_Bot\\ncatbot2\\plugins\\virtual_friend

Total : 0 files,  0 codes, 0 comments, 0 blanks, all 0 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details
# Summary

Date : 2025-04-06 11:21:09

Directory d:\\Myyyyyyyyy\\QQ_Bot\\ncatbot2\\plugins\\virtual_friend

Total : 32 files,  1913 codes, 310 comments, 459 blanks, all 2682 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 28 | 1,699 | 310 | 392 | 2,401 |
| Markdown | 1 | 152 | 0 | 64 | 216 |
| JSON | 2 | 58 | 0 | 3 | 61 |
| pip requirements | 1 | 4 | 0 | 0 | 4 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 32 | 1,913 | 310 | 459 | 2,682 |
| . (Files) | 6 | 329 | 28 | 100 | 457 |
| ai_utils | 4 | 203 | 41 | 48 | 292 |
| config | 3 | 64 | 4 | 11 | 79 |
| handlers | 4 | 153 | 25 | 40 | 218 |
| mem0_integration | 12 | 892 | 180 | 187 | 1,259 |
| mem0_integration (Files) | 4 | 174 | 31 | 41 | 246 |
| mem0_integration\\test | 8 | 718 | 149 | 146 | 1,013 |
| memory | 3 | 272 | 32 | 73 | 377 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)
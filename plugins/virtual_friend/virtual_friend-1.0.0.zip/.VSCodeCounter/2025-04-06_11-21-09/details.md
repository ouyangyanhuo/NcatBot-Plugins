# Details

Date : 2025-04-06 11:21:09

Directory d:\\Myyyyyyyyy\\QQ_Bot\\ncatbot2\\plugins\\virtual_friend

Total : 32 files,  1913 codes, 310 comments, 459 blanks, all 2682 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 152 | 0 | 64 | 216 |
| [\_\_init\_\_.py](/__init__.py) | Python | 2 | 1 | 1 | 4 |
| [ai\_utils/\_\_init\_\_.py](/ai_utils/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [ai\_utils/ai\_helper.py](/ai_utils/ai_helper.py) | Python | 133 | 17 | 32 | 182 |
| [ai\_utils/check\_memory.py](/ai_utils/check_memory.py) | Python | 25 | 22 | 5 | 52 |
| [ai\_utils/img\_handler.py](/ai_utils/img_handler.py) | Python | 45 | 2 | 10 | 57 |
| [config/\_\_init\_\_.py](/config/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [config/characters.json](/config/characters.json) | JSON | 34 | 0 | 2 | 36 |
| [config/config\_loader.py](/config/config_loader.py) | Python | 30 | 4 | 8 | 42 |
| [handlers/\_\_init\_\_.py](/handlers/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [handlers/private\_handler.py](/handlers/private_handler.py) | Python | 79 | 16 | 21 | 116 |
| [handlers/task\_manager.py](/handlers/task_manager.py) | Python | 64 | 9 | 17 | 90 |
| [handlers/user\_state.py](/handlers/user_state.py) | Python | 10 | 0 | 1 | 11 |
| [main.py](/main.py) | Python | 106 | 26 | 27 | 159 |
| [mem0\_integration/RAG\_memory.py](/mem0_integration/RAG_memory.py) | Python | 72 | 14 | 18 | 104 |
| [mem0\_integration/\_\_init\_\_.py](/mem0_integration/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [mem0\_integration/em\_ollama.py](/mem0_integration/em_ollama.py) | Python | 14 | 3 | 3 | 20 |
| [mem0\_integration/qdrant.py](/mem0_integration/qdrant.py) | Python | 88 | 14 | 19 | 121 |
| [mem0\_integration/test/couriapi\_use.py](/mem0_integration/test/couriapi_use.py) | Python | 93 | 2 | 13 | 108 |
| [mem0\_integration/test/doubao.py](/mem0_integration/test/doubao.py) | Python | 134 | 16 | 28 | 178 |
| [mem0\_integration/test/doubao2.py](/mem0_integration/test/doubao2.py) | Python | 15 | 19 | 6 | 40 |
| [mem0\_integration/test/huggingface\_t2v\_ch.py](/mem0_integration/test/huggingface_t2v_ch.py) | Python | 101 | 2 | 11 | 114 |
| [mem0\_integration/test/huggingface\_t2v\_multi.py](/mem0_integration/test/huggingface_t2v_multi.py) | Python | 102 | 2 | 12 | 116 |
| [mem0\_integration/test/huggingface\_use.py](/mem0_integration/test/huggingface_use.py) | Python | 93 | 2 | 12 | 107 |
| [mem0\_integration/test/mem0\_client.py](/mem0_integration/test/mem0_client.py) | Python | 131 | 88 | 40 | 259 |
| [mem0\_integration/test/ollama\_use.py](/mem0_integration/test/ollama_use.py) | Python | 49 | 18 | 24 | 91 |
| [memory/\_\_init\_\_.py](/memory/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [memory/memory\_manager.py](/memory/memory_manager.py) | Python | 232 | 31 | 64 | 327 |
| [memory/user\_manager.py](/memory/user_manager.py) | Python | 40 | 1 | 8 | 49 |
| [requirements.txt](/requirements.txt) | pip requirements | 4 | 0 | 0 | 4 |
| [t.json](/t.json) | JSON | 24 | 0 | 1 | 25 |
| [test\_util.py](/test_util.py) | Python | 41 | 1 | 7 | 49 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)
'''
使用豆包的embedder
使用豆包官方python SDK，直接对qdrant数据库存入和读取向量数据（3072维，无法降维使用）
匹配效果最好
速度快（应该是mem0慢，直接用数据库是快的）
'''
import time
start_time = time.time()
import os
import requests
from volcenginesdkarkruntime import Ark
from qdrant_client import QdrantClient
from qdrant_client.models import VectorParams, Distance, PointStruct
print(f"import用时：{time.time() - start_time}")

start_time=time.time()
client1 = Ark(api_key="2c580434-69be-46b8-928c-fa90b85993c6")
print(f"初始化豆包客户端用时：{time.time() - start_time}")

start_time=time.time()
client2 = QdrantClient(host="172.25.87.18", port=6333)
print(f"初始化qdrant客户端用时：{time.time() - start_time}")
def get_embedding(text):

    # 请求 Volcengine API 获取嵌入向量
    print("----- multimodal embeddings request -----")
    resp = client1.multimodal_embeddings.create(
        model="doubao-embedding-vision-241215",
        encoding_format="float",
        input=[{"text": text, "type": "text"}]
    )

    if hasattr(resp, "data") and resp.data:
        # 获取嵌入向量数据
        embedding = resp.data["embedding"]
        return embedding  # 假设返回第一个嵌入向量
    else:
        print("错误：未接收到嵌入数据")
        return None


def create_collection_if_not_exists(client, collection_name="doubao"):
    # 检查集合是否存在
    collections = client2.get_collections()
    existing_names = {col.name.lower(): col.name for col in collections.collections}
    if collection_name not in existing_names:
        # 设置向量参数
        vectors_config = VectorParams(
            size=3072,  # 根据你的嵌入向量的大小选择合适的尺寸
            distance=Distance.COSINE  # 使用余弦相似度作为距离度量
        )

        # 创建集合
        client2.create_collection(
            collection_name=collection_name,
            vectors_config=vectors_config  # 传递向量配置
        )
        print(f"集合 '{collection_name}' 已创建。")
    else:
        print(f"集合 '{collection_name}' 已存在。")


def store_vector_in_qdrant(vector, content,collection_name="doubao", vector_id=1):
    start_time = time.time()

    # 确保集合存在
    create_collection_if_not_exists(client2, collection_name)

    # 创建 PointStruct 对象
    point = PointStruct(id=vector_id, vector=vector,payload={"content":content})  # 确保向量是列表类型
    # 将向量存储到 Qdrant
    client2.upsert(
        collection_name=collection_name,
        points=[point],  # 使用唯一 ID

    )
    print(f"ID 为 {vector_id} 的向量成功存储在 Qdrant 中。")
    print(f"存储时间：{time.time() - start_time}秒")


def query_vector_in_qdrant(query_vector, collection_name="doubao", top_k=5):
    start_time = time.time()

    # 使用 query 替代 search，查询最相似的 top_k 向量
    query_result = client2.query_points(
    collection_name=collection_name,
    query=query_vector,
    with_payload=True,
    limit=top_k
    ).points
    print(f"查询时间：{time.time() - start_time}秒")
    return query_result


def main():
    print("开始执行main函数")

    texts = [
    # 科学知识
    "光速是每秒299,792,458米。",
    "万有引力定律由牛顿提出，描述了两个物体之间的引力关系。",
    "爱因斯坦的相对论改变了我们对时间和空间的理解。",
    "水的沸点在标准大气压下是100摄氏度。",
    "DNA是所有已知生物的遗传物质。",
    "人工智能是一门研究如何让机器执行通常需要人类智能的任务的学科。",
    "神经网络是深度学习的核心技术。",
    "太阳是一个炽热的气体球，主要由氢和氦组成。",
    "光合作用是植物利用太阳能制造食物的过程。",
    "地球的自转导致了昼夜交替。",
    "月球的引力影响地球的潮汐。",
    "黑洞的视界是光也无法逃脱的边界。",
    
    # 计算机技术
    "Python是一种流行的编程语言，适用于数据科学和人工智能。",
    "Rust 语言以安全性和并发性著称。",
    "Docker 可以用于容器化应用，简化部署和环境管理。",
    "Kubernetes 是一个用于管理容器化应用的编排工具。",
    "SQL 是一种用于操作数据库的查询语言。",
    "计算机网络包括OSI七层模型和TCP/IP协议。",
    "Git 是一个分布式版本控制系统。",
    "Linux 是一种开源操作系统，广泛用于服务器和嵌入式设备。",
    
    # 体育运动
    "篮球是一项团队运动，每队五名球员。",
    "足球比赛时间为90分钟，上下半场各45分钟。",
    "奥运会是世界上规模最大的综合性运动会。",
    "马拉松比赛的标准距离是42.195公里。",
    "羽毛球比赛采用三局两胜制。",
    
    # 文化历史
    "中国的四大发明包括造纸术、印刷术、火药和指南针。",
    "《三国演义》讲述了东汉末年至三国时期的历史故事。",
    "长城是中国古代的军事防御工程。",
    "甲骨文是中国已知最早的文字。",
    "文艺复兴是欧洲14至17世纪的文化运动。",
    "莎士比亚是英国著名的剧作家，代表作包括《哈姆雷特》和《罗密欧与朱丽叶》。",
    
    # 生活常识
    "每天饮用足够的水有助于身体健康。",
    "均衡饮食包括蛋白质、碳水化合物、脂肪、维生素和矿物质。",
    "适量运动有助于维持良好的心血管健康。",
    "睡眠不足会影响记忆力和专注力。",
    "长时间使用电子屏幕可能会导致眼睛疲劳。",
    
    # 经济金融
    "通货膨胀是指货币购买力下降的现象。",
    "股票市场的价格受供需关系和市场情绪影响。",
    "比特币是一种去中心化的数字货币。",
    "银行的主要业务包括存款、贷款和支付结算。",
    
    # 旅行与地理
    "撒哈拉沙漠是世界上最大的沙漠。",
    "珠穆朗玛峰是世界最高的山峰。",
    "亚马逊雨林是全球最大的热带雨林。",
    "中国的首都是北京。",
    "法国的标志性建筑埃菲尔铁塔位于巴黎。",
]
    ids=1
    for text in texts:
        embedding_vector = get_embedding(text)
        store_vector_in_qdrant(embedding_vector, content=text,vector_id=ids)
        ids+=1

    while True:
        text = input("请输入查询文本：（输入exit退出）")
        if text=="exit":
            break
        embedding_vector = get_embedding(text)
        if embedding_vector:
            query_results = query_vector_in_qdrant(embedding_vector, top_k=5)
            print("\n查询结果：")
            for result in query_results:
                print(result)


if __name__ == "__main__": 
    main()

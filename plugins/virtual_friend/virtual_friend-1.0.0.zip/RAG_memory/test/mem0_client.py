'''
直接使用mem0配置embedder
使用的embedder是本地ollama模型bge-m3（1024维）
效果不错
查询速度快
目前综合评分高
'''
import datetime
import json
import os
import time
from datetime import datetime, timedelta
os.environ["MEM0_TELEMETRY"] = "false" # 禁用posthog上传
from mem0 import Memory

def get_relative_date(description: str) -> str:
    """处理中文相对时间描述（如'下周三'）转换为具体日期"""
    today = datetime.now()
    if "下周" in description:
        weekday_map = {"一": 0, "二":1, "三":2, "四":3, "五":4, "六":5, "日":6}
        target_day = next((k for k in weekday_map if k in description), None)
        if target_day:
            days_ahead = (weekday_map[target_day] - today.weekday()) % 7 + 7
            return (today + timedelta(days=days_ahead)).strftime("%Y-%m-%d")
    return datetime.now().strftime("%Y-%m-%d")

FACT_EXTRACTION_PROMPT = f"""
请严格按以下规则从对话中提取结构化信息：

【提取范围】
1. 客户服务：订单号、物流问题、退换货请求
2. 用户信息：姓名、联系方式、地址等身份标识
3. 产品详情：商品属性（颜色/尺码）、订单时间、支付方式
4. 服务请求：投诉内容、技术支持需求、特殊要求

【时间处理】
- 当前基准日期：{datetime.now().strftime("%Y-%m-%d")}
- 将「今天/明天」等转换为实际日期（示例：输入"明天收货" → "2024-03-20需收货"）
- 处理周描述（如「下周三」→ {get_relative_date('下周三')}）

【输出规范】
1. 严格使用JSON格式：{{"facts": ["条目1", "条目2"]}}
2. 空结果返回：{{"facts": []}}
3. 每个条目为20字内的完整事实陈述
4. 保留原始数字和特殊符号（如#12345）

【参考案例】
输入：我上周买的鞋子尺寸不对想换货
输出：{{"facts": ["{get_relative_date('上周')}购买鞋子", "需要更换尺码"]}}

输入：订单#67890还没到货
输出：{{"facts": ["订单#67890未送达"]}}

输入：我是张三，电话13800138000
输出：{{"facts": ["客户姓名：张三", "联系电话：13800138000"]}}

输入：预订了周五下午两点的维修服务
输出：{{"facts": ["{get_relative_date('周五')} 14:00 预约维修"]}}

【过滤规则】
1. 非服务相关对话返回空列表（如天气、日常闲聊）
2. 假设性表述不提取（例如「可能想退货」）
3. 不处理模糊时间（如「前几天」「过阵子」）

请分析以下对话内容提取事实：
"""

strat_time=time.time()
config = {
    "llm": {
        "provider": "deepseek",
        "config": {
            "api_key": "sk-38b1d8c0152545758b2265cd85ffc3bf",
            "model": "deepseek-chat",
            "deepseek_base_url": "https://api.deepseek.com"
        }
    },
    "embedder": {
        "provider": "ollama",
        "config": {
            "model": "bge-m3",
            "ollama_base_url":"http://127.0.0.1:11434"
        }
    },
    "vector_store": {
        "provider": "qdrant",
        "config": {
            "embedding_model_dims":1024,
            "collection_name": "ollama_bge",
            "host": "172.25.87.18",
            "port": 6333,
        }
    },
    "custom_fact_extraction_prompt": FACT_EXTRACTION_PROMPT
}

memory_client = Memory.from_config(config)
print(f"Memory 初始化时间：{time.time() - strat_time:.2f} 秒")

# 输入文本和用户id，存储到数据库中
def addMemory(messages, user_id):
    start_time=time.time()
    result = memory_client.add(messages, user_id)
    print(f"添加记忆：{result}")
    print(f"用时{time.time() - start_time:.2f}秒")

# 根据输入搜索对应结果，返回带有创建和更新时间，返回值是一个字典列表
def searchMemory(query, user_id):
    strat_time=time.time()
    related_memories = memory_client.search(query=query, user_id=user_id, limit=5) # 这里添加了条数限制，之后可能考虑修改
    
    # 提取记忆内容和对应的创建时间
    memory_array = [
        {"memory": item.get("memory"), "created_at": item.get("created_at"),"update_at":item.get("update_at")}
        for item in related_memories.get("results", [])
    ]
    
    print(f"查询结果：{memory_array}")
    print(f"原始查询结果：{related_memories}")

    # 格式化输出需要的内容
    filtered_results = {
        'results': [
            {
                'memory': item.get('memory'),
                'score': item.get('score')
            } 
            for item in related_memories.get('results', [])
        ]
    }
    print(f"查询结果：\n{'-'*30}")
    print(json.dumps(filtered_results, indent=2, ensure_ascii=False))  # 使用json美化输出
    print('-'*
    30)
    print(f"用时{time.time() - strat_time:.2f}秒")
    
    return memory_array

def main():
    # print("开始执行main函数")
    # # os.environ["DEEPSEEK_API_KEY"] = "sk-38b1d8c0152545758b2265cd85ffc3bf"

    # config = {
    #     "llm": {
    #         "provider": "deepseek",
    #         "config": {
    #             "api_key": "sk-38b1d8c0152545758b2265cd85ffc3bf",
    #             "model": "deepseek-chat",
    #             "deepseek_base_url": "https://api.deepseek.com"
    #         }
    #     },
    #     "embedder": {
    #         "provider": "ollama",
    #         "config": {
    #             "model": "bge-m3",
    #             "ollama_base_url":"http://127.0.0.1:11434"
    #         }
    #     },
    #     "vector_store": {
    #         "provider": "qdrant",
    #         "config": {
    #             "embedding_model_dims":1024,
    #             "collection_name": "ollama_bge",
    #             "host": "172.25.87.18",
    #             "port": 6333,
    #         }
    #     }
    # }
    # start_time=time.time()
    # m = Memory.from_config(config)
    # print(f"Memory 初始化时间：{time.time() - start_time:.2f} 秒")
    
    # messages = [
    # [{"role": "user", "content": "我喜欢吃蛋糕"}],
    # [{"role": "user", "content": "我喜欢吃草莓蛋糕"}],
    # [{"role": "user", "content": "我喜欢看电影"}],
    # [{"role": "user", "content": "我讨厌恐怖电影"}],
    # [{"role": "user", "content": "我喜欢动画电影"}],
    # [{"role": "user", "content": "我周末准备玩"}],
    # [{"role": "user", "content": "毕业需要穿黑色衣服"}],
    # [{"role": "user", "content": "你有出去玩的推荐吗？"},
    #  {"role": "assistant", "content": "去爬山吧！"},
    #  {"role": "user", "content": "我准备去爬山"},
    #  {"role": "user", "content": "爬山需要穿什么衣服？"},
    #  {"role": "assistant", "content": "穿舒适的衣服"}]
    # ]

    # for me in messages:
    #     start_time=time.time()
    #     result = m.add(me, user_id="alice")
    #     print(f"添加记忆：{result}")
    #     print(f"添加记忆时间：{time.time() - start_time:.2f} 秒")

    # while True:
    #     try:
    #         user_input = input("\n请输入查询内容（输入'exit'退出）: ").strip()
            
    #         if user_input.lower() in ['exit', 'quit']:
    #             print("退出查询循环")
    #             break
                
    #         if not user_input:
    #             print("输入不能为空，请重新输入")
    #             continue
                
    #         print(f"\n正在查询：{user_input}")
    #         start_time = time.time()
    #         related_memories = m.search(query=user_input, user_id="alice")
    #         print(f"查询耗时：{time.time() - start_time:.2f} 秒")
            # # 格式化输出需要的内容
            # filtered_results = {
            #     'results': [
            #         {
            #             'memory': item.get('memory'),
            #             'score': item.get('score')
            #         } 
            #         for item in related_memories.get('results', [])
            #     ]
            # }
            # print(f"查询结果：\n{'-'*30}")
            # print(json.dumps(filtered_results, indent=2, ensure_ascii=False))  # 使用json美化输出
            # print('-'*
            # 30)
            
    #     except KeyboardInterrupt:
    #         print("\n检测到中断信号，退出程序")
    #         break
    #     except Exception as e:
    #         print(f"查询出错：{str(e)}")

    # all_memories = m.get_all(user_id="alice")
    # print(f"获取全部记忆：{all_memories}")


    print("开始执行main函数")

    messages = [
    [{"role": "user", "content": "我今天的计划是学习数据库和rust，计划学完多表查询"}],
    [{"role": "user", "content": "我今天的计划是学习英语和数学，计划学完一本书"}]
    ]

    for me in messages:
        addMemory(me, user_id="alice")
        


    user_id="alice"
    while True:
        text=input("请输入查询内容（输入'exit'退出）: ")
        if text=="exit":
            print("退出查询循环")
            break
        print(searchMemory(text,user_id))


if __name__ == '__main__':
    main()


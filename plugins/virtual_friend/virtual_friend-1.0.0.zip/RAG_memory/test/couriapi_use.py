'''
直接使用mem0的config配置embedder
使用的是openai的text-embedding-3-large（1536维）
使用api来自Kouri https://api.kourichat.com
测试结果：
查询数据速度较慢
普遍core偏低，但识别相对还是准确的，性价比一般
'''

import json
import os
os.environ["MEM0_TELEMETRY"] = "false" # 禁用posthog上传
from mem0 import Memory

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))  
CONFIG_FILE_PATH = os.path.join(BASE_DIR, "settings.ini")
def main():
    # os.environ["DEEPSEEK_API_KEY"] = "sk-38b1d8c0152545758b2265cd85ffc3bf"

    config = {
        "llm": {
            "provider": "deepseek",
            "config": {
                "api_key": "sk-38b1d8c0152545758b2265cd85ffc3bf",
                "model": "deepseek-chat",
                "deepseek_base_url": "https://api.deepseek.com"
            }
        },
        "embedder": {
            "provider": "openai",
            "config": {
                "api_key": "sk-cc8Me8ISCAKe4KmA4biE1ejuagiZDUdxeDAWlhHEqrM3THEu",
                "model": "text-embedding-3-large",
                "openai_base_url": "https://api.kourichat.com/v1",
            }
        },
        "vector_store": {
            "provider": "qdrant",
            "config": {
                "embedding_model_dims":1536,
                "collection_name": "kouri_openai",
                "host": "172.25.87.18",
                "port": 6333,
            }
        }
    }

    m = Memory.from_config(config)
    
    messages = [
    [{"role": "user", "content": "我喜欢吃蛋糕"}],
    [{"role": "user", "content": "我喜欢吃草莓蛋糕"}],
    [{"role": "user", "content": "我喜欢看电影"}],
    [{"role": "user", "content": "我讨厌恐怖电影"}],
    [{"role": "user", "content": "我喜欢动画电影"}],
    [{"role": "user", "content": "我周末准备玩"}],
    [{"role": "user", "content": "毕业需要穿黑色衣服"}],
    [{"role": "user", "content": "你有出去玩的推荐吗？"},
     {"role": "assistant", "content": "去爬山吧！"},
     {"role": "user", "content": "我准备去爬山"},
     {"role": "user", "content": "爬山需要穿什么衣服？"},
     {"role": "assistant", "content": "穿舒适的衣服"}]
    ]

    for me in messages:
        result = m.add(me, user_id="alice")
        print(f"添加记忆：{result}")

    while True:
        try:
            user_input = input("\n请输入查询内容（输入'exit'退出）: ").strip()
            
            if user_input.lower() in ['exit', 'quit']:
                print("退出查询循环")
                break
                
            if not user_input:
                print("输入不能为空，请重新输入")
                continue
                
            print(f"\n正在查询：{user_input}")
            related_memories = m.search(query=user_input, user_id="alice")
            # 格式化输出需要的内容
            filtered_results = {
                'results': [
                    {
                        'memory': item.get('memory'),
                        'score': item.get('score')
                    } 
                    for item in related_memories.get('results', [])
                ]
            }
            print(f"查询结果：\n{'-'*30}")
            print(json.dumps(filtered_results, indent=2, ensure_ascii=False))  # 使用json美化输出
            print('-'*
            30)
            
        except KeyboardInterrupt:
            print("\n检测到中断信号，退出程序")
            break
        except Exception as e:
            print(f"查询出错：{str(e)}")

    all_memories = m.get_all(user_id="alice")
    print(f"获取全部记忆：{all_memories}")

if __name__ == '__main__':
    main()
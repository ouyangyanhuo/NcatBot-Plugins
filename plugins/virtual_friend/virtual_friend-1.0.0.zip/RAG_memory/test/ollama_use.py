import os
import requests
from qdrant_client import QdrantClient
from qdrant_client.models import VectorParams, Distance, PointStruct
from ollama import embed

def get_embedding(text):

    response = embed(model='mxbai-embed-large:latest', input=text)
    return response['embeddings'][0]


def create_collection_if_not_exists(client, collection_name="test2"):
    # 检查集合是否存在
    collections = client.get_collections()
    if collection_name not in collections:
        # 设置向量参数
        vectors_config = VectorParams(
            size=1024,  # 根据你的嵌入向量的大小选择合适的尺寸
            distance=Distance.COSINE  # 使用余弦相似度作为距离度量
        )

        # 创建集合
        client.create_collection(
            collection_name=collection_name,
            vectors_config=vectors_config  # 传递向量配置
        )
        print(f"集合 '{collection_name}' 已创建。")
    else:
        print(f"集合 '{collection_name}' 已存在。")


def store_vector_in_qdrant(vector, content,collection_name="test2", vector_id=1):
    # 设置 Qdrant 客户端
    client = QdrantClient(host="172.25.87.18", port=6333)

    # 确保集合存在
    # create_collection_if_not_exists(client, collection_name)

    # 创建 PointStruct 对象
    point = PointStruct(id=vector_id, vector=vector,payload={"content":content})  # 确保向量是列表类型
    # 将向量存储到 Qdrant
    client.upsert(
        collection_name=collection_name,
        points=[point],  # 使用唯一 ID

    )
    print(f"ID 为 {vector_id} 的向量成功存储在 Qdrant 中。")


def query_vector_in_qdrant(query_vector, collection_name="test2", top_k=5):
    # 设置 Qdrant 客户端
    client = QdrantClient(host="172.25.87.18", port=6333)

    # 使用 query 替代 search，查询最相似的 top_k 向量
    query_result = client.query_points(
    collection_name=collection_name,
    query=query_vector,
    with_payload=True,
    limit=top_k
    ).points

    return query_result


def main():
    # texts=["i like movie","i like cartoon","i love cake"]
    # ids=3
    # for text in texts:
    #     embedding_vector = get_embedding(text)
    #     store_vector_in_qdrant(embedding_vector, content=text,vector_id=ids)
    #     ids+=1


    text = "cake"  # 示例输入文本
    embedding_vector = get_embedding(text)

    if embedding_vector:
        #store_vector_in_qdrant(embedding_vector, content=text,vector_id=2)  # 存储向量
        
        # 查询最相似的向量
        query_results = query_vector_in_qdrant(embedding_vector, top_k=5)
        
        print("\n查询结果：")
        for result in query_results:
            print(result)


if __name__ == "__main__": 
    main()

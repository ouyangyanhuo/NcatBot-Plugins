'''
尝试使用豆包的openaiSDK失败
'''
# from openai import OpenAI
# import os

# client = OpenAI(
#     # 替换为您需要调用的模型服务Base Url
#     base_url="https://ark.cn-beijing.volces.com/api/v3/",
#     # 环境变量中配置您的API Key
#     api_key="2c580434-69be-46b8-928c-fa90b85993c6"
# )

# print("----- standard request -----")
# completion = client.chat.completions.create(
#     model="doubao-1-5-pro-32k-250115",
#     messages = [
#         {"role": "system", "content": "你是豆包，是由字节跳动开发的 AI 人工智能助手"},
#         {"role": "user", "content": "常见的十字花科植物有哪些？"},
#     ],
# )
# print(completion.choices[0].message.content)


from openai import OpenAI
import os

client = OpenAI(
    # 替换为您需要调用的模型服务Base Url
    base_url="https://ark.cn-beijing.volces.com/api/v3/",
    # 环境变量中配置您的API Key
    api_key="2c580434-69be-46b8-928c-fa90b85993c6"
)

print("----- embeddings request -----")
resp = client.embeddings.create(
    model="doubao-embedding-vision-241215",
    input=["花椰菜又称菜花、花菜，是一种常见的蔬菜。"]
)
print(resp)
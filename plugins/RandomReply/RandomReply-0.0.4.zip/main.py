import asyncio
import json
import logging
import os
import random
from typing import List, Dict, Any

import httpx
from ncatbot.core.element import MessageChain, Text
from ncatbot.core.message import GroupMessage
from ncatbot.plugin import BasePlugin, CompatibleEnrollment

bot = CompatibleEnrollment


class RandomReply(BasePlugin):
    name = "RandomReply"
    version = "0.0.4"

    default_config = {
        "llm_api_url": "",  # API地址
        "llm_api_key": "",  # API密钥
        "llm_model": "",  # 模型名称
        "bot_name": "",  # 机器人名称
        "default_prompt": "【任务规则】1. 根据当前聊天记录的语境，回复最后1条内容进行回应; 2. 用贴吧老哥的风格的口语化短句回复，禁止使用超过30个字的长句; 3. 模仿真实网友的交流特点：适当使用缩写、流行梗、表情符号; 4. 输出必须为纯文本，禁止任何格式标记或前缀; 5. 当出现多个话题时，优先回应最新的发言内容",
        "reply_chance": 0.1,  # 回复的概率
        "max_retries": 3,  # 最大重试次数
        "request_timeout": 12.0,  # 请求超时时间
        "network_settings": {
            "max_connections": 100,  # 最大连接数
            "max_keepalive": 20,  # 最大保持连接数
            "retry_delay_base": 1.0  # 重试延迟基数
        },
        "advanced": {
            "enable_verbose_logging": "false",  # 是否启用详细日志
            "filter_keywords": [],  # 过滤关键词
            "temperature": 0.7,  # 模型温度
            "max_tokens": 100  # 最大输出字数
        }
    }

    async def on_load(self):
        print(f"{self.name} 插件加载中...")
        """初始化插件"""
        # 初始化日志记录器
        self.logger = logging.getLogger(f"ncatbot.plugin.{self.name}")
        if not hasattr(self, 'logger'):
            self.logger = logging.getLogger(__name__)

        self.config = self.load_config(self.default_config)
        self.llm_api_key = os.getenv('API_KEY') or self.config.get('llm_api_key')

        if not self.llm_api_key:
            help_msg = """
                        请通过以下方式之一设置API密钥：
                        1. 环境变量: export API_KEY='your_key'
                        2. 配置文件: plugins/RandomReply/config.json 中添加 "llm_api_key" 字段
                        """
            self.logger.error(help_msg)
            raise ValueError("API密钥未配置")

        # 初始化HTTP客户端
        self.client = httpx.AsyncClient(
            timeout=self.config["request_timeout"],
            limits=httpx.Limits(
                max_connections=100,
                max_keepalive_connections=20
            )
        )
        self.logger.info(f"{self.name} 插件初始化完成，版本 {self.version}")

    async def close(self):
        await self.client.aclose()
        self.logger.info(f"{self.name} 插件已关闭")

    def format_message_history(self, message_data: Dict) -> List[Dict]:
        try:
            if not message_data or 'data' not in message_data:
                return []

            formatted_history = []
            for msg in message_data.get('data', {}).get('messages', []):
                formatted_history.append({
                    "T": str(msg.get('time', '')),
                    "N": msg.get('sender', {}).get('nickname', ''),
                    "C": msg.get('raw_message', '')
                })
            return formatted_history

        except Exception as e:
            self.logger.error(f"格式化消息历史出错: {str(e)}")
            return []

    async def generate_llm_response(self, history: List[Dict]) -> str | None | Any:
        for attempt in range(self.config["max_retries"]):
            try:
                payload = {
                    "model": self.config['llm_model'],
                    "messages": [{
                        "role": "user",
                        "content": self.config['default_prompt'] + "\n" +
                                   "\n".join([f"{item['N']}: {item['C']}" for item in history])
                    }],
                    "max_tokens": 100
                }

                response = await self.client.post(
                    self.config['llm_api_url'],
                    headers={"Authorization": f"Bearer {self.llm_api_key}"},
                    json=payload
                )
                response.raise_for_status()

                return response.json()['choices'][0]['message']['content'].strip()

            except Exception as e:
                self.logger.warning(f"尝试 {attempt + 1} 失败: {str(e)}")
                if attempt == self.config["max_retries"] - 1:
                    return "生成回复时出错，请稍后再试"
                await asyncio.sleep(1 * (attempt + 1))

    @bot.group_event()
    async def get_group_msg_history(self, msg: GroupMessage):
        if random.random() > self.config["reply_chance"]:
            # print("不回复...")
            return

        try:
            history = await self.api.get_group_msg_history(msg.group_id, 0, 20, False)
            formatted = self.format_message_history(history)
            # print(f"formatted:{formatted}")
            if not formatted:
                return

            reply = await self.generate_llm_response(formatted[-5:])
            await self.api.post_group_msg(
                group_id=msg.group_id,
                rtf=MessageChain([Text(reply)])
            )

        except Exception as e:
            self.logger.error(f"处理群消息出错: {str(e)}")

    def load_config(self, default_config):
        try:
            with open('plugins/RandomReply/config.json', 'r', encoding='utf-8') as f:
                return {**default_config, **json.load(f)}
        except Exception as e:
            self.logger.warning(f"加载配置失败，使用默认配置: {str(e)}")
            return default_config


def setup(bot):
    try:
        plugin = RandomReply(bot)
        bot.add_cleanup_task(plugin.close)
        return plugin
    except Exception as e:
        logging.getLogger("ncatbot.plugin").error(f"初始化RandomReply失败: {str(e)}")
        raise

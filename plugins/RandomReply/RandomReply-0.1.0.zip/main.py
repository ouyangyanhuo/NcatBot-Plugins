import asyncio
import json
import logging
import math
import mimetypes
import os
import pathlib
import random
import re
import traceback
import PyPDF2
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime, timedelta, timezone

import httpx
from ncatbot.core.element import MessageChain, Text
from ncatbot.core.message import GroupMessage
from ncatbot.plugin import BasePlugin, CompatibleEnrollment

import google.generativeai as genai
from google.generativeai.types import (
    HarmCategory,
    HarmBlockThreshold,
    BlockedPromptException,
)
from google.generativeai import GenerationConfig

bot = CompatibleEnrollment


class RandomReply(BasePlugin):
    name = "RandomReply"
    version = "0.1.0"

    default_config = {
        # LLM（大语言模型）相关配置
        "llm_api_url": "",  # LLM API 接口地址
        "llm_api_key": "",  # LLM API 密钥
        "llm_model": "",  # 使用的LLM模型名称（如 gpt-4）
        # 嵌入模型相关配置
        "embedding_api_url": "",  # 嵌入API端点
        "embedding_model": "",  # 嵌入模型名称（如 "text-embedding-ada-002"）
        # 聊天机器人基础配置
        "bot_name": "",  # 机器人名称
        "default_prompt": "",  # 默认提示词
        "reply_chance": 0.05,  # 随机回应的概率（0到1之间）
        "max_retries": 3,  # API请求最大重试次数
        "request_timeout": 30.0,  # 请求超时时间（秒）
        # 知识库相关配置
        "knowledge_base": {
            "enabled": True,  # 是否启用知识库功能
            "docs_folder": "res/docs",  # 知识库文档存放路径
            "vector_db_path": "res/vector/vector_db.json",  # 向量数据库保存路径
            "chunk_size": 500,  # 文档分块大小（每块token数）
            "chunk_overlap": 100,  # 分块之间的重叠token数
            "top_k": 3,  # 检索时返回Top-K相关文档块数量
        },
        # Prompt工程配置（提示词生成）
        "prompt_engineering": {
            "use_chat_history": True,  # 是否使用聊天历史生成提示词
            "max_history_tokens": 1500,  # 聊天历史最大token数限制
            "history_window": 10,  # 最近消息窗口大小（条数）
        },
        # 网络请求相关配置
        "network_settings": {
            "max_connections": 100,  # 最大并发连接数
            "max_keepalive": 20,  # 最大保持连接数量
            "retry_delay_base": 1.0,  # 重试延迟的基础秒数
        },
        # 高级配置
        "advanced": {
            "enable_verbose_logging": False,  # 是否启用详细日志
            "filter_keywords": [],  # 用于过滤回复内容的关键词列表
            "temperature": 0.7,  # LLM输出的随机性（越高越随机）
            "max_tokens": 150,  # LLM回复的最大token数
        },
        # 命令系统配置
        "commands": {
            "enable_commands": True,  # 是否启用命令功能
            "allowed_groups": [],  # 允许使用命令的群组ID（空列表表示全部）
            "allowed_users": [],  # 允许使用命令的用户ID（空列表表示全部）
        },
        # 嵌入特性扩展配置
        "embedding_features": {
            "enabled": True,  # 是否启用嵌入特性
            "similarity_threshold": 0.85,  # 相似度阈值（用于匹配是否相关）
            "cache_size": 100,  # 嵌入缓存大小
            "use_for_topic_tracking": True,  # 是否用于话题追踪（上下文相关性）
        },
        # gemini配置
        "gemini": {
            "api_key": "",
            "safety_settings": {
                "harassment": "block_none",
                "hate_speech": "block_none",
                "sexually_explicit": "block_none",
                "dangerous_content": "block_none",
            },
        },
    }

    # 初始化插件
    async def on_load(self):
        """初始化插件"""
        self.logger = logging.getLogger(f"ncatbot.plugin.{self.name}")

        self.config = self.load_config(self.default_config)
        self.llm_api_key = os.getenv("SILICONFLOW_API_KEY") or self.config.get(
            "llm_api_key"
        )
        self.gemini_api_key = os.getenv("GEMINI_API_KEY") or self.config.get(
            "gemini", {}
        ).get("api_key")

        if not self.llm_api_key and not self.gemini_api_key:
            self.logger.error("API密钥未配置")
            raise ValueError("API密钥未配置")

        # 初始化Gemini（如果配置了密钥）
        if self.gemini_api_key:
            try:
                genai.configure(api_key=self.gemini_api_key)
                self.logger.info("Gemini API已初始化")
            except Exception as e:
                self.logger.error(f"Gemini API初始化失败: {str(e)}")

        # 初始化HTTP客户端
        self.client = httpx.AsyncClient(
            timeout=self.config["request_timeout"],
            limits=httpx.Limits(
                max_connections=self.config["network_settings"]["max_connections"],
                max_keepalive_connections=self.config["network_settings"][
                    "max_keepalive"
                ],
            ),
        )

        # 初始化向量数据库（仅当知识库启用时）
        if self.config["knowledge_base"]["enabled"]:
            self.vector_db = self.load_vector_db()

            # 确保知识库文件夹存在
            os.makedirs(self.config["knowledge_base"]["docs_folder"], exist_ok=True)

            # 检查向量数据库是否需要更新
            await self.update_knowledge_base()
        else:
            self.vector_db = {
                "documents": [],
                "embeddings": [],
                "metadata": {"last_updated": "", "files_indexed": []},
            }
            self.logger.warning("知识库功能已禁用")

        self.logger.info(f"{self.name} 插件初始化完成，版本 {self.version}")

    # 关闭插件
    async def close(self):
        """关闭插件"""
        await self.client.aclose()
        # 保存向量数据库
        self.save_vector_db()
        self.logger.info(f"{self.name} 插件已关闭")

    # 加载向量数据库
    def load_vector_db(self) -> Dict:
        """加载向量数据库"""
        try:
            path = self.config["knowledge_base"]["vector_db_path"]
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.logger.info(
                    f"成功加载向量数据库，包含 {len(data.get('documents', []))} 个文档块"
                )
                return data
            else:
                self.logger.info("向量数据库文件不存在，将创建新的数据库")
                return {
                    "documents": [],
                    "embeddings": [],
                    "metadata": {"last_updated": "", "files_indexed": []},
                }
        except Exception as e:
            self.logger.error(f"加载向量数据库失败: {str(e)}")
            return {
                "documents": [],
                "embeddings": [],
                "metadata": {"last_updated": "", "files_indexed": []},
            }

    # 保存向量数据库
    def save_vector_db(self):
        """保存向量数据库"""
        try:
            path = self.config["knowledge_base"]["vector_db_path"]
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.vector_db, f, ensure_ascii=False, indent=2)
            self.logger.info(
                f"向量数据库已保存，包含 {len(self.vector_db.get('documents', []))} 个文档块"
            )
        except Exception as e:
            self.logger.error(f"保存向量数据库失败: {str(e)}")

    # 检查并更新知识库
    async def update_knowledge_base(self):
        """检查并更新知识库"""
        # 如果知识库被禁用，直接返回
        if not self.config["knowledge_base"]["enabled"]:
            self.logger.info("知识库功能已禁用，跳过更新")
            return
        try:
            docs_folder = Path(self.config["knowledge_base"]["docs_folder"])
            if not docs_folder.exists():
                self.logger.warning(f"知识库文件夹不存在: {docs_folder}")
                return

            # 获取所有文档文件
            doc_files = []
            for ext in [".txt", ".md", ".json", ".csv", ".html", ".pdf"]:
                doc_files.extend(list(docs_folder.glob(f"**/*{ext}")))

            if not doc_files:
                self.logger.info("知识库文件夹中没有找到文档")
                # 如果文件夹为空但向量数据库不为空，清空向量数据库
                if self.vector_db.get("documents", []):
                    self.vector_db["documents"] = []
                    self.vector_db["embeddings"] = []
                    self.vector_db["metadata"]["files_indexed"] = []
                    self.vector_db["metadata"][
                        "last_updated"
                    ] = datetime.now().isoformat()
                    self.save_vector_db()
                    self.logger.info("所有文档已被删除，向量数据库已清空")
                return

            # 检查哪些文件需要更新
            indexed_files_dict = {}
            for file_id in self.vector_db.get("metadata", {}).get("files_indexed", []):
                if ":" in file_id:
                    rel_path = file_id.split(":")[0]
                    indexed_files_dict[rel_path] = file_id

            current_files = set()
            new_files = []

            # 处理新文件和修改的文件
            for file_path in doc_files:
                rel_path = str(file_path.relative_to(docs_folder))
                current_files.add(rel_path)
                file_mtime = int(os.path.getmtime(file_path))
                file_id = f"{rel_path}:{file_mtime}"

                if (
                    rel_path in indexed_files_dict
                    and indexed_files_dict[rel_path] != file_id
                ):
                    # 文件已更新，需要重新处理
                    new_files.append((file_path, rel_path, file_id))
                elif rel_path not in indexed_files_dict:
                    # 新文件
                    new_files.append((file_path, rel_path, file_id))

            # 处理已删除的文件
            deleted_files = set(indexed_files_dict.keys()) - current_files
            if deleted_files:
                self.logger.info(
                    f"发现 {len(deleted_files)} 个文件已被删除，正在更新向量数据库"
                )
                self.remove_deleted_documents(deleted_files)

            if not new_files and not deleted_files:
                self.logger.info("知识库已是最新，无需更新")
                return

            if new_files:
                self.logger.info(
                    f"发现 {len(new_files)} 个新文档或已修改文档，开始更新知识库"
                )
                # 处理新文件
                for file_path, rel_path, file_id in new_files:
                    await self.process_document(file_path, rel_path, file_id)

            # 更新元数据
            self.vector_db["metadata"]["last_updated"] = datetime.now().isoformat()
            self.vector_db["metadata"]["files_indexed"] = [
                indexed_files_dict[rel_path]
                for rel_path in indexed_files_dict.keys()
                if rel_path not in deleted_files
            ] + [file_id for _, _, file_id in new_files]

            # 保存更新后的数据库
            self.save_vector_db()

        except Exception as e:
            self.logger.error(f"更新知识库失败: {str(e)}")

    # 处理单个文档文件
    async def process_document(self, file_path: Path, rel_path: str, file_id: str):
        """处理单个文档文件"""
        try:
            self.logger.info(f"处理文档: {rel_path}")

            # 读取文件内容
            text = self.read_document(file_path)
            if not text:
                return

            # 文本分块
            chunks = self.chunk_text(
                text,
                self.config["knowledge_base"]["chunk_size"],
                self.config["knowledge_base"]["chunk_overlap"],
            )

            # 为每个块生成嵌入向量
            for i, chunk in enumerate(chunks):
                embedding = await self.generate_embedding(chunk)
                if embedding:
                    # 添加到向量数据库
                    self.vector_db["documents"].append(
                        {
                            "text": chunk,
                            "source": rel_path,
                            "chunk_id": i,
                            "file_id": file_id,
                        }
                    )
                    self.vector_db["embeddings"].append(embedding)

            self.logger.info(f"已处理文档 {rel_path}，生成 {len(chunks)} 个文档块")

        except Exception as e:
            self.logger.error(f"处理文档 {rel_path} 失败: {str(e)}")

    # 从向量数据库中删除已被删除的文件的文档块
    def remove_deleted_documents(self, deleted_files):
        """从向量数据库中删除已被删除的文件的文档块"""
        try:
            if not deleted_files:
                return

            # 创建新的文档和嵌入列表，排除已删除的文件
            new_documents = []
            new_embeddings = []

            for i, doc in enumerate(self.vector_db.get("documents", [])):
                source = doc.get("source", "")
                # 检查文档来源是否在已删除文件列表中
                if not any(
                    source == deleted_file or source.startswith(f"{deleted_file}/")
                    for deleted_file in deleted_files
                ):
                    new_documents.append(doc)
                    if i < len(self.vector_db.get("embeddings", [])):
                        new_embeddings.append(self.vector_db["embeddings"][i])

            # 更新向量数据库
            deleted_count = len(self.vector_db.get("documents", [])) - len(
                new_documents
            )
            self.vector_db["documents"] = new_documents
            self.vector_db["embeddings"] = new_embeddings

            self.logger.info(f"已从向量数据库中删除 {deleted_count} 个文档块")

        except Exception as e:
            self.logger.error(f"删除文档块失败: {str(e)}")

    # 读取文档内容
    def read_document(self, file_path: Path) -> str:
        """读取文档内容"""
        try:
            ext = file_path.suffix.lower()

            if ext in [".txt", ".md", ".html"]:
                with open(file_path, "r", encoding="utf-8") as f:
                    return f.read()

            elif ext == ".json":
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # 尝试将JSON转为文本
                    if isinstance(data, str):
                        return data
                    else:
                        return json.dumps(data, ensure_ascii=False)

            elif ext == ".csv":
                with open(file_path, "r", encoding="utf-8") as f:
                    return f.read()

            elif ext == ".pdf":
                # 实现PDF读取功能
                return self.read_pdf(file_path)

            else:
                self.logger.warning(f"不支持的文件类型: {ext}")
                return ""

        except Exception as e:
            self.logger.error(f"读取文档 {file_path} 失败: {str(e)}")
            return ""

    # 读取PDF文件内容
    def read_pdf(self, file_path: Path) -> str:
        """读取PDF文件内容"""
        if PyPDF2 is None:
            self.logger.error("无法读取PDF文件：PyPDF2库未安装")
            return ""

        try:
            text_content = []
            with open(file_path, "rb") as f:
                pdf_reader = PyPDF2.PdfReader(f)

                # 获取PDF的元数据
                info = pdf_reader.metadata
                if info:
                    meta_text = "文档信息:\n"
                    for key, value in info.items():
                        if value and str(value).strip():
                            clean_key = key.replace("/", "")
                            meta_text += f"{clean_key}: {value}\n"
                    text_content.append(meta_text)

                # 读取PDF页面内容
                total_pages = len(pdf_reader.pages)
                self.logger.info(f"PDF共有 {total_pages} 页")

                for i, page in enumerate(pdf_reader.pages):
                    try:
                        page_text = page.extract_text()
                        if page_text:
                            text_content.append(f"--- 第{i+1}页 ---\n{page_text}")
                        else:
                            self.logger.warning(f"第{i+1}页未能提取到文本内容")
                    except Exception as e:
                        self.logger.error(f"读取PDF第{i+1}页失败: {str(e)}")

            return "\n\n".join(text_content)

        except Exception as e:
            self.logger.error(f"读取PDF文件失败: {str(e)}")
            return ""

    # 将文本分割成块
    def chunk_text(self, text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
        """将文本分割成块"""
        if not text:
            return []

        # 按段落分割
        paragraphs = re.split(r"\n\s*\n", text)

        chunks = []
        current_chunk = ""

        for para in paragraphs:
            # 如果段落本身超过chunk_size，则需要进一步分割
            if len(para) > chunk_size:
                # 按句子分割
                sentences = re.split(r"(?<=[。！？.!?])\s*", para)
                for sentence in sentences:
                    if len(current_chunk) + len(sentence) <= chunk_size:
                        current_chunk += sentence + " "
                    else:
                        if current_chunk:
                            chunks.append(current_chunk.strip())
                        current_chunk = sentence + " "
            else:
                # 检查是否需要开始新的chunk
                if len(current_chunk) + len(para) > chunk_size:
                    chunks.append(current_chunk.strip())
                    # 新chunk要包含前一chunk末尾的overlap部分
                    last_words = " ".join(
                        current_chunk.split()[-int(chunk_overlap / 10) :]
                    )
                    current_chunk = last_words + " " + para + "\n\n"
                else:
                    current_chunk += para + "\n\n"

        # 添加最后一个chunk
        if current_chunk:
            chunks.append(current_chunk.strip())

        return chunks

    # 为文本生成嵌入向量
    async def generate_embedding(self, text: str) -> Optional[List[float]]:
        """为文本生成嵌入向量"""
        try:
            payload = {"model": self.config["embedding_model"], "input": text}

            response = await self.client.post(
                self.config["embedding_api_url"],
                headers={"Authorization": f"Bearer {self.llm_api_key}"},
                json=payload,
            )
            response.raise_for_status()
            result = response.json()

            # 根据硅基流动API的返回格式提取嵌入向量
            embedding = result.get("data", [{}])[0].get("embedding", [])

            if not embedding:
                self.logger.warning("未能获取嵌入向量")
                return None

            return embedding

        except Exception as e:
            self.logger.error(f"生成嵌入向量失败: {str(e)}")
            return None

    # 搜索与查询相似的文档块
    async def search_similar_docs(self, query: str, top_k: int = None) -> List[Dict]:
        """搜索与查询相似的文档块"""
        # 如果知识库被禁用，直接返回空列表
        if not self.config["knowledge_base"]["enabled"]:
            self.logger.info("知识库功能已禁用，跳过搜索")
            return []
        if top_k is None:
            top_k = self.config["knowledge_base"]["top_k"]

        if not self.vector_db["documents"]:
            self.logger.warning("向量数据库为空，无法执行搜索")
            return []

        try:
            # 生成查询的嵌入向量
            query_embedding = await self.generate_embedding(query)
            if not query_embedding:
                return []

            # 计算相似度并排序
            similarities = []
            for i, doc_embedding in enumerate(self.vector_db["embeddings"]):
                # 使用余弦相似度
                similarity = self.cosine_similarity(query_embedding, doc_embedding)
                similarities.append((similarity, i))

            # 取top_k个最相似的文档
            top_results = sorted(similarities, key=lambda x: x[0], reverse=True)[:top_k]

            results = []
            for similarity, idx in top_results:
                doc = self.vector_db["documents"][idx]
                results.append(
                    {
                        "text": doc["text"],
                        "source": doc["source"],
                        "similarity": similarity,
                    }
                )

            return results

        except Exception as e:
            self.logger.error(f"搜索相似文档失败: {str(e)}")
            return []

    # 计算两个向量的余弦相似度
    def cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """计算两个向量的余弦相似度"""
        if len(vec1) != len(vec2):
            self.logger.error(f"向量维度不匹配: {len(vec1)} vs {len(vec2)}")
            return 0.0

        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = math.sqrt(sum(a * a for a in vec1))
        norm2 = math.sqrt(sum(b * b for b in vec2))

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return dot_product / (norm1 * norm2)

    # 格式化聊天记录
    def format_message_history(self, message_data: Dict) -> List[Dict]:
        try:
            if not message_data or "data" not in message_data:
                return []

            tz = timezone(timedelta(hours=8))  # 北京时间（东八区）

            return [
                {
                    "T": (
                        datetime.fromtimestamp(int(msg.get("time", 0)), tz).strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )
                        if msg.get("time")
                        else ""
                    ),
                    "N": msg.get("sender", {}).get("nickname", ""),
                    "C": msg.get("raw_message", ""),
                }
                for msg in message_data.get("data", {}).get("messages", [])
            ]

        except Exception as e:
            self.logger.error(f"格式化消息历史出错: {str(e)}")
            return []

    # 根据最新消息和聊天历史生成优化的提示词
    async def generate_optimized_prompt(
        self, history: List[Dict], query: str
    ) -> Tuple[str, List[Dict]]:
        """根据最新消息和聊天历史生成优化的提示词"""
        try:
            # 获取最近的聊天历史
            history_window = min(
                len(history), self.config["prompt_engineering"]["history_window"]
            )
            recent_history = history[-history_window:]

            # 获取与查询相关的知识库内容（仅当知识库启用时）
            knowledge_context = ""
            if self.config["knowledge_base"]["enabled"]:
                relevant_docs = await self.search_similar_docs(query)

                # 构建相关知识库内容的文本
                if relevant_docs:
                    knowledge_context = "参考以下相关信息：\n\n"
                    for i, doc in enumerate(relevant_docs):
                        knowledge_context += f"[文档{i+1}] {doc['text']}\n\n"

            # 构建系统指令
            system_instructions = (
                self.config["default_prompt"]
                + "\n"
                + f"""
    每条聊天记录的格式为:  "T": "消息发送时间", "N": "发送者的昵称", "C": "消息内容" 
    请始终保持自然随意的对话风格，避免完整句式或逻辑论述。输出禁止包含任何格式标记或前缀和分析过程,禁止包含任何格式标记或前缀和分析过程，禁止包含任何格式标记或前缀和分析过程,你只需要发送消息内容部分
    在下面的历史聊天记录中,你的名字为{self.config.get('bot_name')},你将作为群成员在群里聊天,现在请处理最新消息："""
            )

            # 增加知识库内容
            if knowledge_context:
                system_instructions += "\n\n" + knowledge_context

            # self.logger.info(f"系统指令：{system_instructions}")
            self.logger.info(f"聊天历史：{recent_history}")

            return system_instructions, recent_history

        except Exception as e:
            self.logger.error(f"生成优化提示词失败: {str(e)}")
            return self.config["default_prompt"], history

    # 调用 LLM 生成回复
    async def generate_llm_response(
        self, history: List[Dict], image_path: str = None
    ) -> str | None | Any:
        """调用 LLM 生成回复"""
        if not history:
            return None

        latest_message = history[-1]["C"] if history else ""

        # 生成优化的提示词
        system_instructions, recent_history = await self.generate_optimized_prompt(
            history, latest_message
        )

        # 格式化历史记录
        formatted_history = "\n".join(
            [f"T: {msg['T']}, N: {msg['N']}, C: {msg['C']}" for msg in recent_history]
        )
        full_prompt = system_instructions + "\n" + formatted_history

        # 获取当前使用的模型名称
        model_name = self.config["llm_model"]

        # 检查是否使用Gemini模型
        if model_name.startswith("gemini-") and self.gemini_api_key:
            return await self.generate_gemini_response(
                full_prompt, image_path=image_path
            )
        else:
            # 使用原有的LLM API
            return await self.generate_default_llm_response(full_prompt)

    # 使用默认LLM API生成回复
    async def generate_default_llm_response(self, full_prompt: str) -> str | None | Any:
        """使用默认LLM API生成回复"""
        for attempt in range(self.config["max_retries"]):
            try:
                payload = {
                    "model": self.config["llm_model"],
                    "messages": [{"role": "user", "content": full_prompt}],
                    "temperature": self.config["advanced"]["temperature"],
                    "max_tokens": self.config["advanced"]["max_tokens"],
                }

                response = await self.client.post(
                    self.config["llm_api_url"],
                    headers={"Authorization": f"Bearer {self.llm_api_key}"},
                    json=payload,
                )
                response.raise_for_status()

                return response.json()["choices"][0]["message"]["content"].strip()

            except Exception as e:
                error_detail = traceback.format_exc()
                self.logger.warning(f"尝试 {attempt + 1} 失败: {e}\n{error_detail}")
                if attempt == self.config["max_retries"] - 1:
                    return "生成回复时出错，请稍后再试"
                await asyncio.sleep(
                    self.config["network_settings"]["retry_delay_base"] * (attempt + 1)
                )

    # 使用Gemini API生成回复
    async def generate_gemini_response(
        self, prompt: str, image_path: str = None
    ) -> str | None:
        """使用Gemini API生成回复"""
        model_name = self.config["llm_model"]

        for attempt in range(self.config["max_retries"]):
            try:
                # 创建异步任务来调用Gemini API
                loop = asyncio.get_event_loop()

                # 配置安全设置和生成参数
                safety_settings = {
                    HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
                    HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
                    HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
                    HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
                }

                generation_config = GenerationConfig(
                    temperature=self.config["advanced"]["temperature"],
                    max_output_tokens=self.config["advanced"]["max_tokens"],
                    top_p=0.95,
                    top_k=40,
                )

                # 在单独的线程中执行以避免阻塞事件循环
                def run_gemini():
                    model = genai.GenerativeModel(
                        model_name=model_name,
                        generation_config=generation_config,
                        safety_settings=safety_settings,
                    )

                    if image_path:
                        image_path_obj = pathlib.Path(image_path)
                        mime_type, _ = mimetypes.guess_type(image_path)
                        if not mime_type or not mime_type.startswith("image/"):
                            return "提供的文件不是有效图片"
                        with open(image_path_obj, "rb") as img_file:
                            image_data = img_file.read()

                        # 构造图文输入
                        content = [
                            {"text": prompt},
                            {
                                "inline_data": {
                                    "mime_type": mime_type,
                                    "data": image_data,
                                }
                            },
                        ]
                        response = model.generate_content(content)
                    else:
                        response = model.generate_content(prompt)

                    # self.logger.info(f"生成的回复:{response}")

                    # 尝试获取 response.text，如果不可用则从结构中提取内容
                    if hasattr(response, "text") and response.text:
                        return response.text
                    elif hasattr(response, "candidates") and response.candidates:
                        # 尝试从 candidates 中提取
                        parts = response.candidates[0].content.parts
                        if parts:
                            return parts[0].text
                    return "无法生成回复"

                # 在线程池中运行Gemini API调用
                result = await loop.run_in_executor(None, run_gemini)
                return result

            except BlockedPromptException as e:
                self.logger.error(f"提示被拦截，原因：{e.prompt_feedback.block_reason}")
                return "提示词被屏蔽，请检查提示词内容"
            except Exception as e:
                error_detail = traceback.format_exc()
                self.logger.warning(
                    f"Gemini尝试 {attempt + 1} 失败: {e}\n{error_detail}"
                )
                if attempt == self.config["max_retries"] - 1:
                    return "使用Gemini生成回复时出错，请稍后再试"
                await asyncio.sleep(
                    self.config["network_settings"]["retry_delay_base"] * (attempt + 1)
                )

    # 检测是否 @ 了 bot
    async def is_at_me(self, msg: GroupMessage) -> bool | str:
        """检测是否 @ 了 bot 或 reply了bot的消息且同时@了bot，并提取其中的图片"""
        try:
            if not hasattr(msg, "raw_message"):
                return False

            bot_qq = str(msg.self_id)  # 机器人QQ号
            raw_msg = msg.raw_message

            # 检查是否at了机器人
            at_me = f"[CQ:at,qq={bot_qq}]" in raw_msg

            # 如果没有被at，直接返回False
            if not at_me:
                return False

            # 检查是否回复了消息
            reply_match = re.search(r"\[CQ:reply,id=(\d+)\]", raw_msg)
            is_reply = bool(reply_match)

            # 处理at的情况，检查消息中是否有图片
            if hasattr(msg, "message"):
                for item in msg.message:
                    if item.get("type") == "image":
                        image_file = item.get("data", {}).get("file")
                        if image_file:
                            self.logger.info(f"检测到 @ 且发现图片 file: {image_file}")
                            return image_file

            # 如果是回复消息，获取被回复的消息中的图片
            if is_reply:
                reply_id = reply_match.group(1)
                try:
                    reply_msg = await self.api.get_msg(message_id=int(reply_id))
                    if (
                        reply_msg
                        and "data" in reply_msg
                        and "message" in reply_msg["data"]
                    ):
                        # 处理reply_msg中的消息
                        message_content = reply_msg["data"]["message"]

                        # 如果message_content是列表形式
                        if isinstance(message_content, list):
                            for item in message_content:
                                if item.get("type") == "image":
                                    image_file = item.get("data", {}).get("file")
                                    if image_file:
                                        self.logger.info(
                                            f"检测到 @ 且reply中发现图片 file: {image_file}"
                                        )
                                        return image_file

                        # 如果message_content是字符串形式，查找CQ码中的图片
                        elif isinstance(message_content, str):
                            img_match = re.search(
                                r"\[CQ:image,.*?file=([^,\]]+)", message_content
                            )
                            if img_match:
                                image_file = img_match.group(1)
                                self.logger.info(
                                    f"检测到 @ 且reply中发现图片 file: {image_file}"
                                )
                                return image_file

                except Exception as e:
                    self.logger.error(f"获取回复消息失败: {e}")

            # 被at但没有图片
            self.logger.info("检测到 @ 但未发现图片")
            return True

        except Exception as e:
            error_detail = traceback.format_exc()
            self.logger.error(f"检测 @ 出错: {e}\n{error_detail}")
            return False

    # 检查消息是否是命令
    def is_command(self, msg_text: str) -> Tuple[bool, str, List[str]]:
        """检查消息是否是命令，并返回命令和参数"""
        if not self.config["commands"]["enable_commands"]:
            return False, "", []

        # 只使用简单的 "/" 前缀
        simple_prefix = "/"

        if msg_text.startswith(simple_prefix):
            # 使用简单的 "/" 前缀
            cmd_text = msg_text[len(simple_prefix) :].strip()
        else:
            return False, "", []

        # 分割命令和参数
        parts = cmd_text.split()
        if not parts:
            return True, "", []

        cmd = parts[0].lower()
        args = parts[1:] if len(parts) > 1 else []

        return True, cmd, args

    # 处理命令
    async def handle_command(self, msg: GroupMessage, cmd: str, args: List[str]):
        """处理命令"""
        try:
            # 如果知识库被禁用，且命令与知识库相关，提供相应提示
            if not self.config["knowledge_base"]["enabled"] and cmd in [
                "update",
                "status",
                "search",
            ]:
                return await self.api.post_group_msg(
                    group_id=msg.group_id,
                    rtf=MessageChain([Text("知识库功能已禁用，无法执行相关命令")]),
                )

            if cmd == "toggle":
                # 添加新命令来开启/关闭知识库
                new_state = not self.config["knowledge_base"]["enabled"]
                self.config["knowledge_base"]["enabled"] = new_state

                # 保存配置
                config_path = "plugins/RandomReply/config.json"
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump(self.config, f, ensure_ascii=False, indent=2)

                # 如果是开启知识库，需要进行初始化
                if new_state:
                    self.vector_db = self.load_vector_db()
                    await self.update_knowledge_base()
                    return await self.api.post_group_msg(
                        group_id=msg.group_id,
                        rtf=MessageChain([Text("知识库功能已开启")]),
                    )
                else:
                    self.vector_db = {
                        "documents": [],
                        "embeddings": [],
                        "metadata": {"last_updated": "", "files_indexed": []},
                    }
                    return await self.api.post_group_msg(
                        group_id=msg.group_id,
                        rtf=MessageChain([Text("知识库功能已关闭")]),
                    )

            elif cmd == "update":
                # 强制更新知识库
                await self.update_knowledge_base()
                return await self.api.post_group_msg(
                    group_id=msg.group_id, rtf=MessageChain([Text("知识库更新完成")])
                )

            elif cmd == "status":
                # 查看知识库状态
                files_indexed = self.vector_db.get("metadata", {}).get(
                    "files_indexed", []
                )
                if not self.vector_db or not self.vector_db.get("documents", []):
                    status_text = "知识库状态：空\n没有索引任何文档"
                else:
                    num_docs = len(self.vector_db.get("documents", []))
                    num_files = len(
                        self.vector_db.get("metadata", {}).get("files_indexed", [])
                    )
                    last_updated = self.vector_db.get("metadata", {}).get(
                        "last_updated", "未知"
                    )

                    status_text = f"""知识库状态：
已索引文件数：{num_files}
文档块数量：{num_docs}
最后更新时间：{last_updated}"""

                if files_indexed:
                    # Format the list of files for display
                    file_list_text = "\n".join([f"- {file}" for file in files_indexed])
                    status_text += f"""
已索引文件列表：
{file_list_text}"""
                else:
                    status_text += "\n已索引文件列表：无"

                return await self.api.post_group_msg(
                    group_id=msg.group_id, rtf=MessageChain([Text(status_text)])
                )

            elif cmd == "search":
                # 搜索相关内容
                if not args:
                    return await self.api.post_group_msg(
                        group_id=msg.group_id,
                        rtf=MessageChain([Text("请提供搜索关键词")]),
                    )

                query = " ".join(args)
                results = await self.search_similar_docs(query, top_k=3)

                if not results:
                    return await self.api.post_group_msg(
                        group_id=msg.group_id,
                        rtf=MessageChain([Text("未找到相关内容")]),
                    )

                response = f"搜索结果：\n\n"
                for i, doc in enumerate(results):
                    similarity = round(doc["similarity"] * 100, 2)
                    response += f"【{i+1}】相关度：{similarity}%\n"
                    response += f"来源：{doc['source']}\n"
                    response += f"{doc['text'][:200]}...\n\n"

                return await self.api.post_group_msg(
                    group_id=msg.group_id, rtf=MessageChain([Text(response)])
                )

            # 添加切换模型的命令
            elif cmd == "model":
                if not args:
                    # 列出可用模型
                    available_models = [
                        "gemini-2.5-flash-preview-04-17",
                        "gemini-2.5-pro-preview-03-25",
                        "gemini-2.0-flash",
                        "gemini-2.0-flash-lite",
                        "deepseek-ai/DeepSeek-V3",
                    ]

                    current_model = self.config["llm_model"]
                    model_text = f"当前模型: {current_model}\n可用模型:\n"
                    for model in available_models:
                        model_text += f"- {model}\n"

                    return await self.api.post_group_msg(
                        group_id=msg.group_id, rtf=MessageChain([Text(model_text)])
                    )
                else:
                    # 切换到指定模型
                    model_name = args[0]

                    # 检查是否是Gemini模型但没有配置API密钥
                    if model_name.startswith("gemini-") and not self.gemini_api_key:
                        return await self.api.post_group_msg(
                            group_id=msg.group_id,
                            rtf=MessageChain(
                                [Text("未配置Gemini API密钥，无法切换到Gemini模型")]
                            ),
                        )

                    # 更新配置
                    self.config["llm_model"] = model_name

                    # 保存配置
                    config_path = "plugins/RandomReply/config.json"
                    with open(config_path, "w", encoding="utf-8") as f:
                        json.dump(self.config, f, ensure_ascii=False, indent=2)

                    return await self.api.post_group_msg(
                        group_id=msg.group_id,
                        rtf=MessageChain([Text(f"已切换模型到: {model_name}")]),
                    )

            elif cmd == "help":
                # 更新帮助信息
                help_text = f"""命令帮助:
/jm <id> - 下载漫画
/file_list <查看数量> - 查看群文件
/update_file <文件序号> - 上传文件到知识库
/daily - 每日新闻
/model [模型名] - 查看或切换LLM模型
知识库相关命令：
    /toggle - 开启/关闭知识库功能
    /update - 更新知识库
    /status - 查看知识库状态
    /search <关键词> - 搜索相关内容
    /help - 显示帮助信息
    当前知识库状态: {'已开启' if self.config["knowledge_base"]["enabled"] else '已关闭'}"""

                return await self.api.post_group_msg(
                    group_id=msg.group_id, rtf=MessageChain([Text(help_text)])
                )

            elif (
                cmd == "jm"
                or cmd == "file_list"
                or cmd == "update_file"
                or cmd == "daily"
            ):
                return

            else:
                # 未知命令
                return await self.api.post_group_msg(
                    group_id=msg.group_id,
                    rtf=MessageChain(
                        [Text(f"未知命令: {cmd}\n请使用 /help 查看可用命令")]
                    ),
                )

        except Exception as e:
            self.logger.error(f"处理命令出错: {str(e)}")
            return await self.api.post_group_msg(
                group_id=msg.group_id,
                rtf=MessageChain([Text(f"处理命令时出错: {str(e)}")]),
            )

    # 处理群消息
    @bot.group_event()
    async def get_group_msg_history(self, msg: GroupMessage):
        """处理群消息"""
        try:
            # 检查是否是命令
            if hasattr(msg, "raw_message"):
                is_cmd, cmd, args = self.is_command(msg.raw_message)

                # 如果是命令，处理命令
                if is_cmd:
                    # 检查权限
                    if (
                        self.config["commands"]["allowed_groups"]
                        and msg.group_id
                        not in self.config["commands"]["allowed_groups"]
                    ):
                        self.logger.info(f"群 {msg.group_id} 没有权限使用命令")
                        return

                    if (
                        self.config["commands"]["allowed_users"]
                        and msg.user_id not in self.config["commands"]["allowed_users"]
                    ):
                        self.logger.info(f"用户 {msg.user_id} 没有权限使用命令")
                        return

                    await self.handle_command(msg, cmd, args)
                    return

            # 检测是否 @ bot 或随机触发
            at_me = await self.is_at_me(msg)
            # at_me = False
            chance = random.random()

            if self.config["advanced"]["enable_verbose_logging"]:
                self.logger.info(f"当前概率:{chance}, @me:{at_me}")

            img_info = None
            # 如果 at_me 是字符串，说明可能是 @ 内容，自动视为 True
            if isinstance(at_me, str):
                img_info = await self.api.get_image(at_me)
                at_me_flag = True
            elif isinstance(at_me, bool):
                at_me_flag = at_me
            else:
                at_me_flag = False  # 意外类型，默认不触发

            # 判断是否要回复
            should_reply = at_me_flag or (chance <= self.config["reply_chance"])

            if not should_reply:
                self.logger.info("未触发回复")
                return

            # 获取历史消息
            history = await self.api.get_group_msg_history(msg.group_id, 0, 30, False)
            formatted = self.format_message_history(history)

            if img_info:  # 如果含有图片
                recent_history = [formatted[-1]]  # 只保留最新一条消息
            else:
                recent_history = formatted  # 否则保留完整历史

            if not formatted:
                self.logger.warning("无法获取有效的消息历史")
                return await self.api.post_group_msg(
                    group_id=msg.group_id, text="无法获取有效的消息历史"
                )

            if self.config["advanced"]["enable_verbose_logging"]:
                self.logger.info(f"最新消息: {formatted[-1]}")

            image_path = (
                img_info.get("data", {}).get("file")
                if img_info and isinstance(img_info, dict)
                else None
            )

            # 生成回复
            reply = await self.generate_llm_response(
                recent_history, image_path=image_path
            )
            if not reply:
                self.logger.warning("未能生成有效回复")
                return await self.api.post_group_msg(
                    group_id=msg.group_id, text="未能生成有效回复"
                )

            # 发送回复
            await self.api.post_group_msg(
                group_id=msg.group_id, rtf=MessageChain([Text(reply)])
            )

        except Exception as e:
            error_detail = traceback.format_exc()
            self.logger.error(f"处理群消息出错: {str(e)}\n{error_detail}")

    # 加载配置
    def load_config(self, default_config):
        try:
            config_path = "plugins/RandomReply/config.json"
            os.makedirs(os.path.dirname(config_path), exist_ok=True)

            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    user_config = json.load(f)

                # 智能合并配置，保留未在用户配置中但在默认配置中的项目
                merged_config = self.deep_merge(default_config, user_config)

                # 如果合并后的配置与用户配置不同，保存回文件
                if merged_config != user_config:
                    with open(config_path, "w", encoding="utf-8") as f:
                        json.dump(merged_config, f, ensure_ascii=False, indent=2)

                return merged_config
            else:
                # 配置文件不存在，创建新文件
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump(default_config, f, ensure_ascii=False, indent=2)
                self.logger.info(f"已创建默认配置文件: {config_path}")
                return default_config

        except Exception as e:
            self.logger.warning(f"加载配置失败，使用默认配置: {str(e)}")
            return default_config

    # 合并两个配置信息
    def deep_merge(
        self,
        default_dict: Dict[str, Any],
        user_dict: Dict[str, Any],
        merge_lists: bool = False,
        merge_sets: bool = False,
    ) -> Dict[str, Any]:
        """
        深度合并两个字典，支持复杂数据结构

        Args:
            default_dict: 默认字典
            user_dict: 用户提供的字典（优先级更高）
            merge_lists: 是否合并列表（True 则拼接，False 则覆盖）
            merge_sets: 是否合并集合（True 则取并集，False 则覆盖）

        Returns:
            合并后的字典
        """
        result = {}
        # 先处理 default_dict 的键
        for key, default_value in default_dict.items():
            if key in user_dict:
                user_value = user_dict[key]
                # 处理 dict 合并
                if isinstance(default_value, dict) and isinstance(user_value, dict):
                    result[key] = self.deep_merge(
                        default_value, user_value, merge_lists, merge_sets
                    )
                # 处理 list 合并（可选）
                elif (
                    merge_lists
                    and isinstance(default_value, list)
                    and isinstance(user_value, list)
                ):
                    result[key] = default_value + user_value
                # 处理 set 合并（可选）
                elif (
                    merge_sets
                    and isinstance(default_value, set)
                    and isinstance(user_value, set)
                ):
                    result[key] = default_value | user_value
                else:
                    result[key] = user_value
            else:
                result[key] = default_value

        # 添加 user_dict 独有的键
        for key, user_value in user_dict.items():
            if key not in default_dict:
                result[key] = user_value

        return result


def setup(bot):
    try:
        plugin = RandomReply(bot)
        bot.add_cleanup_task(plugin.close)
        return plugin
    except Exception as e:
        logging.getLogger("ncatbot.plugin").error(f"初始化RandomReply失败: {str(e)}")
        raise

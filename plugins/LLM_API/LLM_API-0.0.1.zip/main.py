from ncatbot.plugin import BasePlugin, CompatibleEnrollment, Event
from ncatbot.core.message import GroupMessage, PrivateMessage
import asyncio
import httpx
import openai
from concurrent.futures import ThreadPoolExecutor

bot = CompatibleEnrollment  # 兼容回调函数注册器

DEFAULT_URL = "url"
DEFAULT_API = "api"
DEFAULT_MODEL = "model"

class LLM_API(BasePlugin):
    name = "LLM_API" # 插件名称
    version = "0.0.1" # 插件版本

    async def on_load(self):
        # 插件加载时执行的操作, 可缺省
        print(f"{self.name} 插件已加载")
        print(f"插件版本: {self.version}")
        self.register_config("url", DEFAULT_URL)
        self.register_config("api", DEFAULT_API)
        self.register_config("model", DEFAULT_MODEL)
        self.register_handler("LLM_API.main", self.main)
        self.register_admin_func("test", self.test, raw_message_filter="/tllma", permission_raise=True)
    
    async def test(self, message: PrivateMessage):
        result = (await self.publish_async(Event("LLM_API.main", {
                "history": [
                {
                    "role": "system",
                    "content": "系统提示内容"
                },
                {
                    "role": "user",
                    "content": "用户输入内容"
                },
            ], # 提示信息
            "max_tokens": 4096, # 最大长度
            "temperature": 0.7 # 温度, 0-1, 越大越随机
        })))[0]
        await message.reply(text=result["text"] + result['error'])        
        
    async def main(self, event: Event):
        data = event.data
        url = self.data['config']["url"]
        api = self.data['config']["api"]
        model = self.data['config']["model"]
        
        if url == DEFAULT_URL or api == DEFAULT_API or model == DEFAULT_MODEL:
            event.add_result({
                "text": "",
                "status": 501,
                "error": "配置项错误"
            })
            return
        
        with ThreadPoolExecutor(max_workers=1) as executor:
            def create_completion():
                return client.chat.completions.create(
                    model=model,
                    messages=data['history'],
                    temperature=data['temperature'],
                    max_tokens=data['max_tokens']
                )
                
            try:
                client = openai.OpenAI(api_key=api, base_url=url)
                loop = asyncio.get_running_loop()
                completion = await loop.run_in_executor(executor, create_completion)
                choice = completion.choices[0]
                event.add_result({
                    "text": choice.message.content,
                    "status": 200,
                    "error": ""
                })
            except Exception as e:
                event.add_result({
                    "text": "",
                    "status": 500,
                    "error": str(e)
                })
    
    async def on_unload(self):
        print(f"{self.name} 插件已卸载")
        
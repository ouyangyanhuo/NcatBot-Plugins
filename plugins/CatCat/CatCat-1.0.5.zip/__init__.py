# __init__.py
from .main import CatCat

__all__ = ["CatCat"]

# __init__.py
from .main import ZDKK

__all__ = ["ZDKK"]
def zidongkuakua(str):
    # 自动夸夸 输入一个人名
    return "你真是太棒了，" + str + "！"

def no_zidongkuakua(str):
    return "你ma，" + str + "！"
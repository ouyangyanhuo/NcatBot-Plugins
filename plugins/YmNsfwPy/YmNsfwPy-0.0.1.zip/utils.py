import httpx

from PIL import Image
from io import BytesIO
from nsfwpy import NSFW 
from .ymconfig import NSFW_CONFIG
from ncatbot.utils.logger import get_log
from ncatbot.core.message import GroupMessage
from ncatbot.plugin import CompatibleEnrollment
from ncatbot.core.element import (
    MessageChain,
    Text,
    At,
)

_log = get_log()

_nc = None

def reset_nc():
    """重置 NSFW 实例"""
    global _nc
    _nc = None

def get_nc():
    """延迟初始化 NSFW 实例"""
    global _nc
    if _nc is None:
        _nc = NSFW(model_type=NSFW_CONFIG.nsfwpy_type)
    return _nc

def is_dangerous_content(check_result, threshold=None):
    """
    判断NSFW检测结果是否属于高危内容，请根据实际场景来修改检测逻辑
    """
    if threshold is None:
        threshold = NSFW_CONFIG.threshold
        
    dangerous_categories = ['porn', 'hentai', 'sexy']
    # 获取危险类别中的最大概率值
    max_prob = max(float(check_result.get(cat, '0')) for cat in dangerous_categories)

    if max_prob >= threshold:
        return True, f"max_prob:{max_prob:.2%}"
    return False, f"max_prob:{max_prob:.2%}"

async def nsfwc(message: GroupMessage, bot: CompatibleEnrollment) -> None:
    for msg in message.message:
        if msg["type"] == "image":
            file_url = f'http{msg["data"]["url"][5::]}'
            try:
                async with httpx.AsyncClient(verify=False,http2=False, trust_env=False,timeout=3) as client:
                    response = await client.get(file_url)
                    if response.status_code == 200:
                        image = Image.open(BytesIO(response.content))
                        check_result = await get_nc().predict_pil_image_async(image)
                        is_dangerous, reason = is_dangerous_content(check_result)
                        if is_dangerous:
                            _log.warning(f"检测到危险内容：{reason}, group_id: {message.group_id}, user_id: {message.user_id}, file_url: {file_url}")
                            content = [
                                Text("发现一条危险内容"),
                            ]
                            admins = NSFW_CONFIG.get_group_admins(message.group_id)
                            for admin in admins:
                                at = At(admin)
                                content.append(at)

                            await bot.api.post_group_msg(message.group_id,reply=message.message_id,rtf=MessageChain(content))
                        else:
                            _log.info(f"NSFW Check Passed: group_id: {message.group_id}, user_id: {message.user_id}, exponent: {reason}")
            except Exception as e:
                _log.error(f"NSFW Check Error: {e}, group_id: {message.group_id}, user_id: {message.user_id}, file_url: {file_url}")
from .ymconfig import NSFW_CONFIG
from ncatbot.core.message import GroupMessage
from ncatbot.plugin import BasePlugin, CompatibleEnrollment
from ncatbot.utils.logger import get_log
from .utils import nsfwc
from ncatbot.core.element import (
    MessageChain,  # 消息链，用于组合多个消息元素
    Text,          # 文本消息
    At,            # @某人
)

bot = CompatibleEnrollment
_log = get_log()

class YmNsfwPy(BasePlugin):
    name = "YmNsfwPy"
    version = "0.0.1"

    # 需指定全局管理员
    GLOBAL_ADMIN = 10000

    @bot.group_event()
    async def on_group_event(self, msg: GroupMessage):
        
        if NSFW_CONFIG.is_group_check_enabled(msg.group_id):
            await nsfwc(msg,self)

        if msg.raw_message[:5] == "添加通知人":
            if msg.user_id in NSFW_CONFIG.get_global_admins():
                for user in msg.message:
                    if user['type'] == "at":
                        NSFW_CONFIG.add_group_admin(msg.group_id, int(user['data']['qq']))
                await msg.reply(text="添加成功")
            else:
                await msg.reply(text="你没有权限执行此操作")

        if msg.raw_message[:5] == "移除通知人":
            if msg.user_id in NSFW_CONFIG.get_global_admins():
                for user in msg.message:
                    if user['type'] == "at":
                        NSFW_CONFIG.remove_group_admin(msg.group_id, int(user['data']['qq']))
                await msg.reply(text="移除成功")
            else:
                await msg.reply(text="你没有权限执行此操作")
        
        if msg.raw_message == "关闭nsfw检测":
            if msg.user_id in NSFW_CONFIG.get_global_admins():
                # 获取现有管理员
                current_admins = NSFW_CONFIG.get_group_admins(msg.group_id)
                NSFW_CONFIG.update_group_settings(msg.group_id, current_admins, False)
                await msg.reply(text="关闭成功")
            else:
                await msg.reply(text="你没有权限执行此操作")
        
        if msg.raw_message == "开启nsfw检测":
            if msg.user_id in NSFW_CONFIG.get_global_admins():
                # 获取现有管理员
                current_admins = NSFW_CONFIG.get_group_admins(msg.group_id)
                NSFW_CONFIG.update_group_settings(msg.group_id, current_admins, True)
                await msg.reply(text="开启成功")
            else:
                await msg.reply(text="你没有权限执行此操作")
        
        if msg.raw_message == "查看通知人":
            if msg.user_id in NSFW_CONFIG.get_global_admins():
                admins = NSFW_CONFIG.get_group_admins(msg.group_id)
                content = [Text("通知人列表：")]
                for admin in admins:
                    at = At(admin)
                    content.append(at)
                await msg.reply(rtf=MessageChain(content))
            else:
                await msg.reply(text="你没有权限执行此操作")

        if msg.raw_message.startswith("设置阈值"):
            if msg.user_id in NSFW_CONFIG.get_global_admins():
                try:
                    value = float(msg.raw_message.split()[1])
                    if 0 <= value <= 1:
                        NSFW_CONFIG.threshold = value
                        await msg.reply(text=f"阈值已设置为: {value}")
                    else:
                        await msg.reply(text="阈值必须在0到1之间")
                except (IndexError, ValueError):
                    await msg.reply(text="格式错误！请使用'设置阈值 0.x'的格式，例如：设置阈值 0.6")
            else:
                await msg.reply(text="你没有权限执行此操作")
        
        if msg.raw_message == "查看阈值":
            await msg.reply(text=f"当前阈值为: {NSFW_CONFIG.threshold}")
        
        if msg.raw_message.startswith("切换模型"):
            if msg.user_id in NSFW_CONFIG.get_global_admins():
                try:
                    model_type = msg.raw_message.split()[1]
                    if model_type in ['d', 'm2', 'i3']:
                        NSFW_CONFIG.nsfwpy_type = model_type
                        from .utils import reset_nc
                        reset_nc()
                        await msg.reply(text=f"模型已切换为: {model_type}")
                    else:
                        await msg.reply(text="模型类型必须是 d、m2 或 i3 之一")
                except IndexError:
                    await msg.reply(text="格式错误！请使用'切换模型 类型'的格式，例如：切换模型 m2")
            else:
                await msg.reply(text="你没有权限执行此操作")

        if msg.raw_message == "查看当前模型":
            await msg.reply(text=f"当前使用的模型为: {NSFW_CONFIG.nsfwpy_type}")
                
    async def on_load(self):
        # 初始化 NSFW_CONFIG
        NSFW_CONFIG.init_data(self.data)

        admins = NSFW_CONFIG.get_global_admins()
        
        if len(admins) == 0:
            # 如果未指定管理员，则提示添加
            if getattr(self, "GLOBAL_ADMIN", None) is None:
                _log.warning("请在 nsfwpybot/main.py 中指定管理员")
            else:
                NSFW_CONFIG.add_global_admin(self.GLOBAL_ADMIN)
        _log.info(f"当前nsfwpybot管理员： {NSFW_CONFIG.get_global_admins()}")
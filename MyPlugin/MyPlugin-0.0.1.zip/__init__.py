from .main import MyPlugin

__all__ = ["MyPlugin"]